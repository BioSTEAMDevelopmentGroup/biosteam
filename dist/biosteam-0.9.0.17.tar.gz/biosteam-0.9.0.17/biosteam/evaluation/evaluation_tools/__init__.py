# -*- coding: utf-8 -*-
"""
Created on Mon Sep  2 04:58:34 2019

@author: yoelr
"""

from lazypkg import LazyPkg

LazyPkg(__name__, ['parameter', 'plot'])