The BioSTEAM Project Contributors is composed of:

* Yoel Cortes-Pena (Main BioSTEAM author and maintainer)

* Developers who have contributed in person and through email, including:

  * Bugrah Mirsat Sahin

  * Lisa Pardini

  * Brent Scheidemantle

  * Rui Shi

  * Sarang Sunil Bhagwat

  * Yalin Li

* All other developers that have contributed to the biosteam repository:

      https://github.com/BioSTEAMDevelopmentGroup/biosteam/graphs/contributors
