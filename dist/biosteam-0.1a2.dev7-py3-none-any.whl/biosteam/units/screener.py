# -*- coding: utf-8 -*-
"""
Created on Thu Aug 23 22:16:16 2018

@author: yoelr
"""

from biosteam.units.separator import Separator


class Screener(Separator):
    pass
