# -*- coding: utf-8 -*-
"""
Created on Sat Jan  4 05:59:46 2020

@author: yoelr
"""

__all__ = ('H2O_CAS',)

H2O_CAS = '7732-18-5'